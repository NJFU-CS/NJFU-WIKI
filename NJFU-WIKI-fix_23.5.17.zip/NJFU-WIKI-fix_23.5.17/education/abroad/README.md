<br>

## 🌍 出国相关

千人分享
> 夏璨： [努力，来得及；奋斗，别犹豫！](/education/abroad/xiacan.md)  
> 
> [公众号版本: 入魔计](https://mp.weixin.qq.com/s?__biz=MzU5Nzk2NTE4NA==&mid=2247483903&idx=1&sn=639d809d39f4a6561274aecee11bc144&chksm=fe4a2110c93da806ad8f8d8adbe0777ebd3931585f5d4d2d139de6b253db8e49d1ff165d6ce9&mpshare=1&scene=23&srcid=04148WvPw58GWL8rgCUXMHoD&sharer_sharetime=1649901942875&sharer_shareid=156c1d9b3a58976da8dbe3b5ad6ffe7b%23rd)

细节待补充