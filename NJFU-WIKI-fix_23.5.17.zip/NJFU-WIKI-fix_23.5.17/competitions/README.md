<br>

# 计算机相关学科竞赛简介

* [专业技术类](competitions/specific/README.md)
* [通识技能类](competitions/general/README.md)
* [其他类别](competitions/others/README.md)

### 🔗 一些连接

[参考1:2021 年全国普通高校大学生竞赛排行榜](https://www.cahe.edu.cn/site/content/14825.html)    
[参考2:南京林业大学大学生学科竞赛目录(2022版)](https://net.njfu.edu.cn/bcms/front/authorized/read.do?channelid=1799&amp;infoid=249371)