<br>

## 内推资源

| 名称  | 创建人  | 创建帅呢       | 链接                                                                                        |
|-----|------|------------|-------------------------------------------------------------------------------------------|
| 猫肠  | 铃兰君影 | 2022年4月11日 | [前图应届生，后图暑期实习]()                                                                          |
| 宇宙肠 | 惟妙惟霄 | 2022年4月12日 | [23届秋招提前批与面向全体在校生的实习招聘](https://jobs.bytedance.com/campus/position?referral_code=QE7NV7A) |

## 猫肠

<img src="https://dvkunion.oss-cn-shanghai.aliyuncs.com/img/15yvqcij0jGVJBriH8b1Ig.jpeg" style="height: 600px"/>