* 入魔计(纳姐竞赛相关公众号)
    * ![](https://dvkunion.oss-cn-shanghai.aliyuncs.com/img/qrcode.bmp)
* QQ群(加群需要内部学号以及实名备注)
    * ![加群需要内部学号以及实名备注](https://dvkunion.oss-cn-shanghai.aliyuncs.com/WechatIMG62.jpeg)
